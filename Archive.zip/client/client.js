

const socket = io();

// Listen for the 'chat message' event from the server
socket.on('chat message', (msg) => {
  console.log('Received message:', msg);
  // Handle the received message and update the UI
});

// Example: Send a message to the server
const message = 'Hello, server!';
socket.emit('chat message', message);


