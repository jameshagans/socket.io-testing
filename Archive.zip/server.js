

const express = require('express');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http);
const cors = require('cors')
const PORT = 3000; 

app.use(express.static('public'));

io.on('connection', (socket) => {
  console.log('A user has connected')
  console.log('id: ', socket.id)

  socket.on('chat message', (msg) => {
    console.log('Received message:', msg);
    io.emit('chat message', msg); // Broadcast the message to all connected clients
  });

  socket.on('disconnect', () => {
    //console.log('A user disconnected');
  });
});


app.get('/', (req, res) => {
  console.log('request made to /')
  res.sendFile('index.html', { root: __dirname });
});

app.get('/game', (req, res) => {
  console.log('request made to /game')
  res.sendFile('game.html', { root: __dirname });
});

http.listen(PORT, () => {
  console.log('Server listening on port 3000');
});









// io.on('connection', (socket) => {
//   console.log("Client: ", socket.id) // these always change o a new connection
//   console.log('A user has connected');

//   socket.on('chat message', (msg) => {
//     console.log('message: ' + msg);
//   });

//   socket.emit('system', 'Welcome to the server!!')
//   socket.on('disconnect', (socket) => {
//     console.log('A client has disconnected: ', socket.id);
//   }); 
  
//   // socket.broadcast to send to everyone but hte sender 
// });





// http.listen(3000, () => {
//   console.log('Server listening on port 3000');
// });
